<?php
return array(
	'DELETE_30_DAY'=>'Delete all records before January',
	'DELETE_90_DAY'=>'Delete all records before March',
	 
);
?>