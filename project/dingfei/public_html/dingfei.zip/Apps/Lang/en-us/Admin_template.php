<?php 
return array(
	'file_no_find'=>'文件不存！',
	'delete_ok'=>'文件删除成功！',
	'edit_ok' => '模板修改成功！',
	'add_ok'=> '文件创建成功！',
	'file_name'=>'File name',
	'file_size'=>'File size',
	'file_time'=>'Modification time',
	'file_name'=>'File name',
	'file_type_html'=>'模板文件',
	'file_type_css'=>'CSS文件',
	'file_type_js'=>'js文件',
	'filename' => 'File name',
	'goback'=>'返回上一级',
	'upfile'=>'上传文件',
	'upfile_upload_ok'=>'文件上传成功！',
	'add_tpl_param' => '添加模板参数',	

);
?>