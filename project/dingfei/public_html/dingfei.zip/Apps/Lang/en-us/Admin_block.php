<?php
return array(
'add_pic'=>'添加图片',
'pic'=>'图片',
'video'=>'视频',
'link'=>'链接',
'clean_thumb'=>'清除图片',
'upload'=>'上传',
'view'=>'预览',
);
?>