<?php
return array(
		'URL_MAKE_HTML'=>'Static?',
		'URL_example'=>'URL sample',
		'URL_RULE'=>'URL rule',
		'URL_SHOW'=>'content page',
		'URL_LIST'=>'list page',
		'URL_SHOW_VAR'=>'Content page available variable',
		'URL_LIST_VAR'=>'List page available variables',
		'URL_SHOW_README'=>'Column catalogue：{$catdir} , ColumnID：{$catid} , Model name：{$module}  , Module id：{$moduleid}  ，ID：{$id} <br>Year：{$year} Month：{$month}，Day：{$day} ， Paging：{$page}<br>Generate HTML page can use the parent column path：{$parentdir} ',
		'URL_LIST_README'=>'Column catalogue：{$catdir}  ， Column ID：{$catid} , Module name：{$module}  , Module id：{$moduleid} <br> Paging：{$page}<br>Generate HTML page can use the parent column path：{$parentdir}',
);
?>