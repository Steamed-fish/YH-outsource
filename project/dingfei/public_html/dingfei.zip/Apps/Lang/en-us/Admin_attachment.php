<?php 
return array(
	'uploadfiles' => '文件上传',
	'upload_file' => '上传文件',
	'upload_url' => '网络地址',
	'upload_list_file' => '浏览图库',
	'upload_unuse_file' => '未处理文件',
	'upload_say1' => '最多上传',
	'upload_say2' => '个附件,单文件最大 ',
	'upload_say3' => 'MB ',
	'upload_say4' => '支持 ',
	'upload_say5' => '格式。',
	'upload_add_water' => '是否添加水印',
	'upload_say6' => '共选择了',
	'upload_say7' => '个附件,上传失败 ',
	'upload_say8' => '个,成功上传',
	'upload_say9' => '个',
	'upload_fileurl' => '请输入网络地址',
	'NO_USE_FILES'=>'清理未使用的图片',
);
?>