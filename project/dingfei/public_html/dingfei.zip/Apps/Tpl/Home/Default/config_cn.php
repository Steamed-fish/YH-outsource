<?php
return array ( 'dibu_product' => '66', 'product' => '66', 'footer_nav_id' => '20', 'index_case_id' => '4', 'home_product_id' => '3', ); ?>