<?php
return array ( 'm_about_catid' => '20', 'dibu_product' => '21', 'product' => '22', 'news' => '24', 'home_product_id' => '3', ); ?>