<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head lang="en">
	    <meta name="description" content="<?php echo ($seo_description); ?>">
    <meta name="keywords" content="<?php echo ($seo_keywords); ?>">
    <meta charset="utf-8">
    <meta name="renderer" content="webkit"><!--360 极速模式-->
    <link rel="shortcut icon" href="/Apps/Tpl/Home/Default/Public/images/favicon.ico" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=0.8, user-scalable=no"/>
    <title><?php echo ($seo_title); ?></title>
    <link href="../Public/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="../Public/css/owl.carousel.css" rel="stylesheet" type="text/css" />
    <link href="../Public/css/all.css" rel="stylesheet" type="text/css" />
    <link href="../Public/css/app.css" rel="stylesheet" type="text/css" />
    <!--[if lt IE 9]>
    <script src="../Public/js/html5.js"></script>
    <script src="../Public/js/respond.min.js"></script>
    <![endif]-->
    <script type="text/javascript" src="../Public/js/jquery-min.js"></script>
</head>
<body class="<?php echo ($l); ?>">
<div>
	
		<div class="langbox">
		<div class="container">
			<div class="row">
				<span><?php echo ($welcome); ?></span>
			</div>
		</div>
	</div>
	<div class="header">
		<div class="logo">
			<a href="<?php echo str_replace('//', '/', '/'.HOMEURL($l));?>"></a>
		</div>
		<div class="relative">
			<div class="header-u">
				<div class="ol-nav">
					<div class="nav-app">
						<span></span>
						<span></span>
						<span></span>
					</div>
					<ul class="nav-hide">
						<li>
							<a class="top" href="<?php echo str_replace('//', '/', '/'.HOMEURL($l));?>"
							<?php if($_SERVER['REQUEST_URI'] == str_replace('//', '/', '/'.HOMEURL($l)) ) : ?>
							id="nav-li"
							<?php endif;?>
							><?php echo L('首页');?></a>
						</li>
						
						<?php $k=0;foreach($Categorys as $key=>$r):if(1=="" && $r['isfootermenu']==0){ continue; }if( $r['ismenu']==1 && intval(0)==$r["parentid"] ) :++$k;?><li>
							<a class="top <?php echo ($r["cssclass"]); ?>" href="<?php echo ($r["url"]); ?>"
							<?php if($r[id]==$catid) : ?>id="nav-li"<?php endif;?>
							<?php if($r[id]==$Categorys[$catid]['parentid']) : ?>id="nav-li"<?php endif;?>
							><?php echo ($r["catname"]); ?></a>
							<?php if($r['arrchildid'] != $r['id'] ) : ?>
							<ul class='no-animates'>
								<?php $n=0;foreach($Categorys as $key=>$r2):if(1=="" && $r2['isfootermenu']==0){ continue; }if( $r2['ismenu']==1 && intval($r['id'])==$r2["parentid"] ) :++$n;?><li>
									<a href="<?php echo ($r2["url"]); ?>"><?php echo ($r2["catname"]); ?></a>
									</li><?php endif; endforeach;?>
							</ul>
							<?php endif;?>
							</li><?php endif; endforeach;?>
						
					</ul>
				</div>
				<div class='search-lang'>
					<div class='search-box relative'>
						<form name="myform" action="/" method="GET">
							<input type="hidden" name="module" value="Product"/>
							<input type="hidden" name="m" value="Search"/>
							<?php if(APP_LANG) : ?><input type="hidden" name="l" value="<?php echo ($l); ?>" /><?php endif;?>
							<input value='<?php echo ($keyword); ?>' class="search-input" type="text" name="keyword" id="keyword" />
							<button type="submit"></button>
						</form>
					</div>
					<div class="lang relative">
						<span class="icons">Language</span>
						<ul>
							<?php if(is_array($Lang)): $i = 0; $__LIST__ = $Lang;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$r): $mod = ($i % 2 );++$i;?><li>
								<a <?php if($r['id'] == $langid ) : ?> class="active" <?php endif;?>href="<?php echo str_replace('//', '/', '/'.HOMEURL($r[mark]));?>" style="background:none">
									<?php echo ($r["name"]); ?>
								</a>
							</li><?php endforeach; endif; else: echo "" ;endif; ?>
						</ul>
					</div>
					<div class="sharebox relative">
						<span class="icons share"></span>
						<ul>
							<li><a class="icons fb"></a></li>
							<li><a class="icons tw"></a></li>
							<li><a class="icons in"></a></li>
							<li><a class="icons wx"></a></li>
							<li><a class="icons wb"></a></li>
							<li><a class="icons qq"></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div>
	<!--
<div class="container class">
	<div class="row catpos">
      <?php echo L('你的位置：');?> <a  href="<?php if(C('DEFAULT_LANG') == $l ) : ?>/<?php else :?>/?l=<?php echo ($l); endif;?>"><?php echo L('首页');?></a></a> &gt; <?php  $arrparentid = array_filter(explode(',', $Categorys[$catid]['arrparentid'].','.$catid));$icnt = 0;foreach($arrparentid as $cid):$parsestr[] = '<a '.(count($arrparentid)==(++$icnt)?'class="last"':"").'" href="'.$Categorys[$cid]['url'].'">'.$Categorys[$cid]['catname'].'</a>'; endforeach;echo implode(" &gt; ",$parsestr);?>
	</div>
</div>

-->
<img src="<?php echo ($image); ?>"/>



<div class='newdetail'>
    <div class="sub-cate">
  <div class="container">
    <div class="row">
        
	  <?php $ccatid = $catid; ?>
	  <?php if(($Categorys[$catid]&&$Categorys[$catid]['arrchildid']==$catid)) : ?>
	  <?php $ccatid = $Categorys[$catid]['parentid']; ?>
	  <?php endif;?>

	  <!--<div class='page-title'>
            <h2><?php echo ($Categorys[$ccatid]['catname']); ?></h2>
        </div>-->
				
        <div>
          <?php $n=0;foreach($Categorys as $key=>$rd):if(1=="" && $rd['isfootermenu']==0){ continue; }if( $rd['ismenu']==1 && intval($ccatid)==$rd["parentid"] ) :++$n;?><div class='no-animates cat-item <?php if($catid==$rd[id]) : ?>hover<?php endif;?> '>
              <a href="<?php echo ($rd["url"]); ?>" class='sub-name'><?php echo ($rd["catname"]); ?></a>
              <span class='sub-pot icons'></span>
            </div><?php endif; endforeach;?>
          <div class="floatR padd-T-20">
            <?php if($content) : ?><a class="shang" href="<?php echo ($Categorys[$catid]['url']); ?>"><?php echo L('返回列表');?></a><?php else : endif;?>
          </div>
        </div>
        
       
      </div>
  </div>
</div>
</div>

<div class="container newdetail">
  <div class='row'>
    <div class="col-sm-8 col-md-8 col-xs-12 c-left">
      <h1 class="bai"><?php echo ($title); ?></h1>
      <div class='stats'>
        <span><?php echo L('发布时间');?>: <?php echo (todate($createtime,'Y-m-d')); ?></span>
        <span><?php echo L('次浏览');?>: <?php echo ($hits); ?></span>
        <span><?php echo L('分享到');?>: 
          <div class="f-icon icon-maring">
              <!--<a href="" class=""></a><a href=""></a><a href=""></a><a href=""></a><a href=""></a><a href=""></a>-->
              <!-- JiaThis Button BEGIN -->
              <div class="jiathis_style animates">
                <a class="jiathis_button_tqq animates"></a>
                <a class="jiathis_button_tsina animates"></a>
                <a class="jiathis_button_weixin animates"></a>             
                <a class="jiathis_button_qzone animates"></a>
                <a class="jiathis_button_tieba animates"></a>
              </div>
              <!--<script type="text/javascript" src="http://v3.jiathis.com/code/jia.js" charset="utf-8"></script>-->
              <!-- JiaThis Button END -->
          </div>
        </span>
      </div>
      <div class="content">
          <?php echo ($content); ?>
      </div>
      <div class="xiaye pd f14 lh22" style="padding-top: 0;">
        <?php if($nextPage) : ?><div><?php echo L('上一篇');?>:<a class="" href="<?php echo ($nextPage["url"]); ?>"><?php echo ($nextPage["title"]); ?></a></div><?php else : endif;?>
        <?php if($prePage) : ?><div><?php echo L('下一篇');?>:<a class="" href="<?php echo ($prePage["url"]); ?>"><?php echo ($prePage["title"]); ?></a></div><?php else : endif;?>
      </div>
    </div>
    <div class="col-sm-4 col-md-4 col-xs-12 c-right">
      <div class="col-r-title"><?php echo L('最新动态');?></div>
      <ol >
        <?php  $_result=M("Article")->field("*")->where(" 1  and lang=3 AND status=1  AND  thumb !='' ")->order("id desc")->limit("5")->select();; if ($_result): $i=0;foreach($_result as $key=>$r):++$i;$mod = ($i % 2 ); if($key==0) : ?>
            <li class="first">
                <a href='<?php echo ($r["url"]); ?>' title='<?php echo ($r["title"]); ?>'>
                  <img alt='<?php echo ($r["title"]); ?>' src='<?php echo (thumb($r["thumb"],219,135,1)); ?>' />
                  <b><?php echo (str_cut($r["title"],15)); ?></b>
                  <span title="<?php echo ($r["summary"]); ?>"><?php echo ($r["summary"]); ?></span>
                </a>
            </li>
          <?php else :?>
            <li class="icons">
              <a href='<?php echo ($r["url"]); ?>' title='<?php echo ($r["title"]); ?>'>
                <b><?php echo (str_cut($r["title"],15)); ?></b>
                <span title="<?php echo ($r["summary"]); ?>"><?php echo ($r["summary"]); ?></span>
              </a>
            </li>
          <?php endif; endforeach; endif;?>
      </ol>
    </div>
  </div>
</div>
<script type="text/javascript" src="http://v3.jiathis.com/code/jia.js" charset="utf-8"></script>

      
      
      
	</div>
		<div class="footer">
		<div class="container">
			<div class="row">
				<div class="col-sm-12 col-md-4 col-xs-12">
					<div class="foot-contact">
						<span class='foot-nav-title'><?php echo L('联系我们');?></span>
						<ul>
							<li><span class='icons address'></span><?php echo ($address); ?></li>
							<li><span class='icons phone'></span><?php echo ($phone); ?></li>
							<li><span class='icons email'></span><?php echo ($email); ?></li>
						</ul>
					</div>
				</div>
				<div class="col-sm-12 col-md-5 col-xs-12">
					<?php $k=0;foreach($Categorys as $key=>$r):if(1=="1" && $r['isfootermenu']==0){ continue; }if( $r['ismenu']==1 && intval(0)==$r["parentid"] ) :++$k;?><div class='foot-nav col-sm-3 col-md-3 col-xs-3'>
							<span class='foot-nav-title'><?php echo ($r["catname"]); ?></span>
							<?php if($r['arrchildid'] != $r['id'] ) : ?>
							<ul>
							<?php $n=0;foreach($Categorys as $key=>$r2):if(1=="" && $r2['isfootermenu']==0){ continue; }if( $r2['ismenu']==1 && intval($r['id'])==$r2["parentid"] ) :++$n;?><li>
									<a href="<?php echo ($r2["url"]); ?>"><?php echo ($r2["catname"]); ?></a>
								</li><?php endif; endforeach;?>
							</ul>
							<?php endif;?>
						</div><?php endif; endforeach;?>
				</div>
				<div class="col-sm-12 col-md-3 col-xs-12">
					<script>
						function copytitle(){
							$('.feedback-form input[name=title]').val(
								$('.feedback-form textarea [name=content]').val()
							);
							return true;
						}
					</script>
					<form name="myform" action="<?php echo URL('User-Post/insert');?>" onsubmit="return copytitle()" method="post">
						<div class="feedback-form">
							<input type="hidden" name="moduleid" value="8" />
							<input type="hidden" name="lang" value="<?php echo ($langid); ?>" />
							<input type="hidden" name="email" value="" />
							<input type="hidden" name="title" value="" />
							
							<div><input name="username" placeholder="<?php echo L('姓名');?>" /></div>
							<div><input name="telephone" placeholder="<?php echo L('电话');?>" /></div>
							<div><textarea name='content' placeholder="<?php echo L('内容');?>"></textarea></div>
							<div><button type="submit" class="linkdetail"><?php echo L('提交');?></button></div>
						</div>
					</form>
				</div>
				
			</div>
			<div class="row friendlink">
				<b><?php echo L('友情链接');?>: </b>
				<?php  $_result=M("Link")->field("*")->where(" status = 1  and lang=3 and typeid=2 and  linktype=1")->order("id desc")->limit("10")->select();; if ($_result): $i=0;foreach($_result as $key=>$r):++$i;$mod = ($i % 2 );?><a href="<?php echo ($r['siteurl']); ?>" target="_blank" title="<?php echo ($r['name']); ?>"><?php echo ($r['name']); ?></a><?php endforeach; endif;?>
			</div>
		</div>
		<div class="copyright">
			<div><?php echo ($copyright); ?> &nbsp;&nbsp; <a href='http://mqu.cn' target="_blank">design by mqu.cn</a></div>
		</div>
	</div>
	<script type="text/javascript" src="../Public/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="../Public/js/all.js"></script>
	<a style='display:none;' href='http://mqu.cn' target="_blank">design by mqu.cn</a>
	
</div>
</body>
</html>