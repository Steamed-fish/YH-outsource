<?php
/**
 * 
 * 数据库配置文件
 *
 * @package      	YOURPHP
 * @author          yourphp.cn QQ:147613338 <web@yourphp.cn>
 * @copyright     	Copyright (c) 2008-2011  (http://www.yourphp.cn)
 * @license         http://www.yourphp.cn/license.txt
 * @version        	config.php v2.0 2011-03-01 yourphp.cn $
 */
 return array(
	'DB_TYPE'=>'mysql',
	'DB_HOST'=>'127.0.0.1',
	'DB_NAME'=>'dingfei_db',
	'DB_USER'=>'root',
	'DB_PWD'=>'root',
	'DB_PORT'=>'3306',
	'DB_PREFIX'=>'mqu_',
);
?>