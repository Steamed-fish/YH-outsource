<?php
return array ( 'member_register' => '1', 'member_emailcheck' => '0', 'member_registecheck' => '1', 'member_login_verify' => '1', 'member_emailchecktpl' => '', 'member_getpwdemaitpl' => '', ); ?>