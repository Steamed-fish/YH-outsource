<?php
return 123; ?>